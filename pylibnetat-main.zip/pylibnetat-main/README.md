AT command Configuration app for Taixin TX-AH-R WiFi HaLow Modules / devices
<br>**Not working yet WIP
Usage:

add your network interface that is connected to the radio after the command like this:<br>
python ./pylibnetat eth0

